import java.util.Scanner;
public class MyClass {
    public static void main(String args[]) {
      System.out.println("YOUR COMPUTER HAS A VIRUS!!!" );
      System.out.println("YOUR COMPUTER HAS BEEN HACKED!!!" );
      System.out.println("Windows ERROR:6583   SHUTTING DOWN!" );
     System.out.println("" );
     System.out.println("ERROR" );  
        System.out.println("CANNOT CLOSE" );
        System.out.println("" );
        System.out.println("ERROR" );
        System.out.println("" );
        System.out.println("" );
        System.out.println("The Coronavirus has taken over your computer." );
Scanner scanner = new Scanner(System.in); 
scanner.nextLine();

    }
}